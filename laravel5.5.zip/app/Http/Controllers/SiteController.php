<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class SiteController extends Controller
{
    public function Index()
    {
        phpinfo();
        echo 123;
    }
    //即时聊天
    public function chat()
    {
        return view('/site/chat');
    }

}